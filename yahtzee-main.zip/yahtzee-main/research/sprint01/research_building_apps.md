- React Tutorial for Beginners - https://www.youtube.com/watch?v=SqcY0GlETPk

- Nextjs documentation - https://nextjs.org/docs

- Yahtzee game tutorial - https://en.wikipedia.org/wiki/Yahtzee
