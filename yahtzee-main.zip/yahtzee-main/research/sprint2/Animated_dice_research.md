- Rolling the Dice with React Hooks - https://codepen.io/danncortes/pen/rPoVEp

- Rolling Dice with React State - https://coursework.vschool.io/dice-react-state/

- Dice roll animation - https://stackoverflow.com/questions/49219035/dice-roll-animation
    - the third one is the most fit for our project while we have backend logic set already.
