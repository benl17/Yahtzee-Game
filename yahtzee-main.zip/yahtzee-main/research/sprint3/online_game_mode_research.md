- WebSocket introduction and guide:
    - https://www.ruanyifeng.com/blog/2017/05/websocket.html
    - https://jayqiu.github.io/blog/2017/05/blog_05_11_17.html
    - https://ably.com/topic/socketio-vs-websocket

- WebSocket with multiplayer web game:
    - https://jayqiu.github.io/blog/2017/05/blog_05_11_17.html
    - https://jayqiu.github.io/blog/2017/05/blog_05_11_17.html
    - https://jayqiu.github.io/blog/2017/05/blog_05_11_17.html

- Nextjs with Pusher:
    - https://pusher.com/blog/websockets-realtime-gaming-low-latency/#handling-synchronization-and-game-state-updates-with-pusher-channels
