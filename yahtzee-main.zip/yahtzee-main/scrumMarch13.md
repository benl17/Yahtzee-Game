# Scrum March 13th, 2024 highlights

The entire team agreed that our communication has been very good, everyone is on the same page as to what they should be doing on the project as well as letting each other know if someone has run into a problem. We also agreed that we are in a good place with our project as we have a working skeleton that you can play.

One thing that we wanted to improve on was adding unit tests as we have been slacking a little bit on this. We also wanted to improve on writing more documentation.